import 'dart:convert';
import 'dart:async';
import 'dart:ffi';
import 'package:flutter_easyloading/flutter_easyloading.dart';

import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../network/request.dart';
import '../network/url.dart';


class LoginController extends GetxController {

  final getdata = GetStorage();
  late TextEditingController useridTextController;
  late TextEditingController passTextController;
  late TextEditingController mobileNoTextController;
  var action = false.obs;
  final storage = GetStorage();
  RxString imageUploadStatus = ''.obs;

  final double targetLatitude = 37.7749; // Replace with your target latitude
  final double targetLongitude = -122.4194; // Replace with your target longitude
  final double targetRadius = 10.0; // 10 meters radius


  void showLoader() async{
    await EasyLoading.show(
      status: 'loading...',
      maskType: EasyLoadingMaskType.custom,
    );
  }


  @override
  Future<void> onInit() async {
    super.onInit();
    useridTextController = TextEditingController();
    passTextController = TextEditingController();
    mobileNoTextController = TextEditingController();


  }

  void apiLogin() async {
    showLoader();
    String textFormFieldValue = useridTextController.text;
    String textFormFieldValueMobile = mobileNoTextController.text;
    String trimmedValue = textFormFieldValue.trim();

    storage.write('loginID', trimmedValue);

    storage.write('mobileNo', textFormFieldValueMobile);
    Request request = Request(url: urlLogin, body: {
      'login': trimmedValue,
      'password': passTextController.text
    });

    print(request.body);

    request.post().then((value) async {
      var result = json.decode(value.body);
      print(result);
     /* // ignore: avoid_print
      print('result_login'+value.body.toString());
      if (result['status'] == 1) {
        print('userid');
        print(trimmedValue);
        action(false);
        getdata.write('isLoggedIn', true);
        getdata.write('userid', trimmedValue);
        getdata.write('username', result['username']);
        getdata.write('distributorcode', result['distributorcode']);
        getdata.write('designation', result['designation']);
        getdata.write('token', result['token']);
        getdata.write('today_beat', result['today_beat'].toString());

        if(result['user_level']== null){
          getdata.write('user_level', '');
        }else{
          getdata.write('user_level', result['user_level'].toString());
        }

        if(result['sales_code']== null){
          getdata.write('sales_code', '');
        }else{
          getdata.write('sales_code', result['sales_code'].toString());
        }


        print('today_login');
        print(result['today_login']);

        // _checkLocationToTrackUser();

        if (result['today_login'] == 0) {
          ImagePicker().pickImage(
            source: ImageSource.camera,
            maxHeight: 512,
            maxWidth: 512,
            imageQuality: 85,
          ).then((img) {

            if (img != null) {

              // _checkLocationToTrackUser();
              *//*if(srIsWithinPoint){
                  imageUploadStatus.value = 'Selfie uploading.\nPlease wait...';
                  SynchronizationData.isInternet().then((connection) async {
                    if (connection) {

                      showLoader();

                      const uri = urlBase + urlAttendance;
                      Map<String, String> headers = {
                        "Accept": "application/json",
                        "Authorization": 'Bearer ${getdata.read('token')}'
                      };

                      var request = http.MultipartRequest('POST', Uri.parse(uri));
                      request.headers.addAll(headers);

                      request.fields['UserID'] = getdata.read('userid').toString();
                      request.fields['Latitude'] = lat.toString();
                      request.fields['Longitude'] = lon.toString();
                      request.fields['AppVersion'] = version;

                      var pic = await http.MultipartFile.fromPath("image", img.path);

                      print('body_selfie');
                      print(getdata.read('userid'));
                      print(lat.toString());
                      print(lon.toString());
                      print(version);

                      request.files.add(pic);


                      request.send().then((value) {

                        http.Response.fromStream(value).then((response) {
                          if (json.decode(response.body)['success'] == 1) {

                            getdata.write('lastLoginDay', DateTime.now().day);


                            getdata.write('selfieUploaded', 'yes');
                            // first time sync after login
                            // _firstTimeSyncController.apiGetBusinessList();

                            imageUploadStatus = ''.obs;
                            EasyLoading.dismiss();
                            // Get.toNamed('/HomePage');
                            Get.snackbar('Login', result['message'],
                                snackPosition: SnackPosition.TOP);
                            // Get.to(() => const ShowcaseWidget(homePage: HomePage()), transition: Transition.leftToRight,duration: const Duration(milliseconds: 500));
                            Get.to(() => const HomePage(), transition: Transition.leftToRight,duration: const Duration(milliseconds: 500));



                          } else {
                            EasyLoading.dismiss();
                            imageUploadStatus.value = '';
                            Get.snackbar('Error', 'Please try again', backgroundColor: Colors.red,snackPosition: SnackPosition.TOP);
                          }
                        });
                      });
                    }
                  });
                }else{

                }*//*

              imageUploadStatus.value = 'Selfie uploading.\nPlease wait...';
              SynchronizationData.isInternet().then((connection) async {
                if (connection) {

                  showLoader();

                  const uri = urlBase + urlAttendance;
                  Map<String, String> headers = {
                    "Accept": "application/json",
                    "Authorization": 'Bearer ${getdata.read('token')}'
                  };

                  var request = http.MultipartRequest('POST', Uri.parse(uri));
                  request.headers.addAll(headers);

                  request.fields['UserID'] = getdata.read('userid').toString();
                  request.fields['Latitude'] = lat.toString();
                  request.fields['Longitude'] = lon.toString();
                  request.fields['AppVersion'] = version;

                  var pic = await http.MultipartFile.fromPath("image", img.path);

                  print('body_selfie');
                  print(getdata.read('userid'));
                  print(lat.toString());
                  print(lon.toString());
                  print(version);

                  request.files.add(pic);


                  request.send().then((value) {

                    http.Response.fromStream(value).then((response) {
                      if (json.decode(response.body)['success'] == 1) {

                        getdata.write('lastLoginDay', DateTime.now().day);


                        getdata.write('selfieUploaded', 'yes');
                        // first time sync after login
                        // _firstTimeSyncController.apiGetBusinessList();

                        imageUploadStatus = ''.obs;
                        EasyLoading.dismiss();
                        // Get.toNamed('/HomePage');
                        Get.snackbar('Login', result['message'],
                            snackPosition: SnackPosition.TOP);
                        // Get.to(() => const ShowcaseWidget(homePage: HomePage()), transition: Transition.leftToRight,duration: const Duration(milliseconds: 500));
                        Get.to(() => const HomePage(), transition: Transition.leftToRight,duration: const Duration(milliseconds: 500));



                      } else {
                        EasyLoading.dismiss();
                        imageUploadStatus.value = '';
                        Get.snackbar('Error', 'Please try again', backgroundColor: Colors.red,snackPosition: SnackPosition.TOP);
                      }
                    });
                  });
                }
              });



            }  else {

              EasyLoading.dismiss();
              imageUploadStatus.value = '';
              Get.snackbar('Error', 'Image can not be empty', backgroundColor: Colors.red,snackPosition: SnackPosition.TOP);
            }
          });
        } else {
          getdata.write('lastLoginDay', DateTime.now().day);

          getdata.write('selfieUploaded','no');

          // Get.toNamed('/HomePage');
          // Get.to(() => const ShowcaseWidget(homePage: HomePage()), transition: Transition.leftToRight,duration: const Duration(milliseconds: 500));
          Get.to(() => const HomePage(), transition: Transition.leftToRight,duration: const Duration(milliseconds: 500));

          Get.snackbar('Login', result['message'],
              snackPosition: SnackPosition.TOP);
        }


      } else {
        action(false);
        // Get.toNamed('/loginView');
        Get.toNamed('/HomePage');

        Get.snackbar('Login', result['message'],
            colorText: Colors.green,
            backgroundColor: const Color(0xFF252525),
            snackPosition: SnackPosition.TOP);
      }*/
    }).catchError((onError) {
          Get.defaultDialog(
          title: 'LOGIN',
          content:  Center(
              child: Column(
                children: [
                  const Text('Something went wrong in server!!!'),
                  Text(onError.toString()),

                ],
              )),
          barrierDismissible: true);
    });
  }

  void apilogout() {
  /*  getdata.erase();

    Get.offAll(() => const LoginView());
    // Get.offAndToNamed('/loginView');

    Get.snackbar('Logout', 'successfully done.',
        snackPosition: SnackPosition.TOP);*/

  }


}
