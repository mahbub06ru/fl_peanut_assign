import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import 'package:http/http.dart' as http;

class UserController extends GetxController {
  void showLoader() async{
    await EasyLoading.show(
      status: 'loading...',
      maskType: EasyLoadingMaskType.custom,
    );
  }
  void showADialog(String title, String des) {
    Get.dialog(
      AlertDialog(
        title: Text(title),
        content: Text(des),
        actions: [
          TextButton(
            onPressed: () {
              Get.back(); // Dismiss the dialog
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }
  RxBool isLoading = false.obs;
  RxBool loading = false.obs;
  RxString customerCode = ''.obs;

  final storage = GetStorage();
  var token='';


  @override
  void onInit() async{
    super.onInit();

  }

  @override
  void dispose() {
    super.dispose();
  }


}