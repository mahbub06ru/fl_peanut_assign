import 'package:get/get.dart';

import '../controller/login_controller.dart';
import '../controller/user_controller.dart';

class AppBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(LoginController());
    Get.put(UserController());

  }
}
