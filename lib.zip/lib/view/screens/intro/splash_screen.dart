import 'dart:async';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:intl/intl.dart';

import 'package:get/get.dart';
import 'dart:async';
import 'dart:developer' as developer;
import 'package:get_storage/get_storage.dart';

import '../../../controller/login_controller.dart';
import '../../widgets/custom_alert_dialog.dart';
import '../sign_in/sign_in_page.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  SplashPageState createState() => SplashPageState();
}

class SplashPageState extends State<SplashPage> with SingleTickerProviderStateMixin {
  final LoginController controller = Get.find();

  bool? _isConnected;

  Future<void> _checkInternetConnection() async {
    try {
      final response = await InternetAddress.lookup('www.google.com');
      print(response);
      if (response.isNotEmpty) {
        setState(() {
          _isConnected = true;

        });
      }
    } on SocketException catch (err) {
      setState(() {
        _isConnected = false;
      });
      if (kDebugMode) {
        print(err);
      }
    }
  }

  final storage = GetStorage();
  var _visible = true;
  bool?   loading ;
  String? UserID,todaysDate;
  AnimationController? animationController;
  Animation<double>? animation;
  startTime() async {
    var _duration = new Duration(seconds: 3);
    return new Timer(_duration, navigationPage);
  }
  void showInSnackBar(String value) {
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(value,
          textAlign: TextAlign.center, style: const TextStyle(fontSize: 16.0, fontWeight:
          FontWeight.bold),), duration: const Duration(seconds: 2), backgroundColor: Colors.blueAccent,)
    );
    // Get.back();
    // Navigator.pop(context);

  }

  void navigationPage() {
    // detectUser();
    if(_isConnected == true){


      Get.to(() =>  const SignInPage(),
          transition: Transition.leftToRight,
          duration: const Duration(milliseconds: 500));


    }else{

      showDialog(
        barrierColor: Colors.black26,
        context: context,
        builder: (context) {
          return  CustomAlertDialog(
            title: "No Internet !",
            description: "Please enable your internet connection",  posText: 'Enable',negText: 'Later',
            positiveBtn: () {
              Navigator.pop(context);
            },
            negetiveBtn: () {
              Navigator.pop(context);
              SystemNavigator.pop();
            },
          );
        },
      );

    }

  }
  void detectUser() async {
    var now = DateTime.now();
    var dateFormat = DateFormat('yyyy-MM-dd');
    var presentDate = dateFormat.format(now);

    setState(() {
      loading = true;
    });
    final storage = GetStorage();
    UserID= storage.read('UserId');
    todaysDate= storage.read('todaysDate');

    var beforeMercImageLinkDuringVisit=  storage.read('beforeMercImageLink');

    //login one time / day
    if(UserID != null &&  todaysDate != null){
      if(todaysDate == presentDate){
        setState(() {
          Get.back();
          Get.toNamed('/homePage');//homePage//informationPanelListPage//informationPanelListPage//cMPhotoPage
        });
        setState(() {
          loading = false;
        });
      }else{
        setState(() {
          if(storage.read('isTimerRunning') == '1'){ //if happen call and out of screen during visit
            Get.toNamed('/cMVisitScreen');
          }else{
            Get.back();
            Get.toNamed('/signInPage');
          }
        });
        setState(() {
          loading = false;
        });
      }

    }else{
      setState(() {
        Get.back();
        Get.toNamed('/signInPage');
      });
      setState(() {
        loading = false;
      });


    }



  }


  @override
  void initState() {
    super.initState();

    _checkInternetConnection();

    setState(() {
      _visible = !_visible;
    });

    startTime();

  }

  @override
  void dispose() {
    controller.dispose();
    // _connectivitySubscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return  Container(
      constraints: BoxConstraints(
        maxWidth: Get.width,  // Set your maximum width here
        maxHeight: Get.height, // Set your maximum height here
      ),
      child: Image.asset(
        'assets/images/Spash-screen.png',
        fit: BoxFit.fill, // or any other fit value as per your requirement
      ),
    );
  }
}
