import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../controller/login_controller.dart';
import '../../../utils/app_colors.dart';
import '../../../utils/constants.dart';



class SignInPage extends StatefulWidget {
  const SignInPage({Key? key}) : super(key: key);

  @override
  _SignInPageState createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final LoginController _loginController = Get.put(LoginController());
  final _formKey = GlobalKey<FormState>();
  final FocusNode _focusNode = FocusNode();

  final getData = GetStorage();

  var version = "";

  @override
  void initState() {
    super.initState();

    try {
      version = getData.read('AppVersion');
      print(version);
    } catch (e) {
      print(e);
    }
  }

  Future<bool> showExitPopup(context) async {
    return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: SizedBox(
              height: 90,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Do you want to exit?"),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            //  print('yes selected');
                            exit(0);
                          },
                          child: const Text("Yes"),
                          style: ElevatedButton.styleFrom(
                            primary:AppColors.buttonColor, // Change the background color here
                          ),
                        ),
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              //  print('no selected');
                              Navigator.of(context).pop();
                            },
                            child: const Text("No",
                                style: TextStyle(color: Colors.black)),
                            style: ElevatedButton.styleFrom(
                              primary:AppColors.buttonColor, // Change the background color here
                            ),
                          ))
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return WillPopScope(
      onWillPop: () => showExitPopup(context),
      child: SafeArea(
          child: Scaffold(
            backgroundColor: Colors.white,
            body: Stack(
              children: [
                Container(
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('${Constants.assetImagePath}/bgv.png'),
                      fit: BoxFit.cover, // Adjust the fitting as needed
                    ),
                  ),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      width: Get.width,
                      height: MediaQuery.of(context).size.height * 4 / 6,
                      decoration: const BoxDecoration(
                        color: AppColors.appColor,
                        // Change this to your desired background color
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50.0),
                          topRight: Radius.circular(50.0),
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(40.0),
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Form(
                                key: _formKey,
                                autovalidateMode: AutovalidateMode.onUserInteraction,
                                child: ListView(
                                  shrinkWrap: true,
                                  children: [
                                    /* Image.asset(
                                    '${Constants.assetImagePath}/Group 43.png',
                                    width: 300,
                                    height: 100,
                                  ),*/
                                    Container(
                                      decoration: BoxDecoration(
                                        color: Colors.grey[200],
                                        borderRadius: BorderRadius.circular(10.0),
                                      ),
                                      child: TextFormField(
                                        focusNode: _focusNode,
                                        textCapitalization:
                                        TextCapitalization.characters,
                                        controller:
                                        _loginController.useridTextController,
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontFamily: 'OpenSans',
                                          fontSize: 18,
                                        ),
                                        decoration: const InputDecoration(
                                          border: InputBorder.none,
                                          prefixIcon: Icon(
                                            Icons.person,
                                            color: Colors.grey,
                                          ),
                                          hintText: 'ENTER YOUR ID',
                                          hintStyle: TextStyle(
                                            color: Colors.black54,
                                            fontFamily: 'OpenSans',
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                          ),
                                          contentPadding: EdgeInsets.symmetric(
                                              vertical: 15.0, horizontal: 20.0),
                                        ),
                                        validator: (value) =>
                                        value!.trim().isEmpty
                                            ? 'ID required'
                                            : null,
                                        inputFormatters: <TextInputFormatter>[
                                          FilteringTextInputFormatter.deny(
                                              RegExp(r"\s\b|\b\s"))
                                        ],
                                      ),
                                    ),
                                    const SizedBox(height: 10),
                                    Container(
                                      decoration: BoxDecoration(
                                        color: Colors.grey[200],
                                        borderRadius: BorderRadius.circular(10.0),
                                      ),
                                      child: TextFormField(
                                        controller:
                                        _loginController.passTextController,
                                        obscureText: true,
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontFamily: 'OpenSans',
                                          fontSize: 18,
                                        ),
                                        decoration: const InputDecoration(
                                          border: InputBorder.none,
                                          prefixIcon: Icon(
                                            Icons.lock,
                                            color: Colors.grey,
                                          ),
                                          hintText: 'ENTER YOUR PASSWORD',
                                          hintStyle: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black54,
                                            fontFamily: 'OpenSans',
                                            fontSize: 18,
                                          ),
                                          contentPadding: EdgeInsets.symmetric(
                                              vertical: 15.0, horizontal: 20.0),
                                        ),
                                        validator: (value) =>
                                        value!.trim().isEmpty
                                            ? 'Password required'
                                            : null,
                                      ),
                                    ),
                                    const SizedBox(height: 10),
                                    Container(
                                      decoration: BoxDecoration(
                                        color: Colors.grey[200],
                                        borderRadius: BorderRadius.circular(10.0),
                                      ),
                                      child: TextFormField(
                                        keyboardType: TextInputType.phone,
                                        controller: _loginController
                                            .mobileNoTextController,
                                        obscureText: false,
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontFamily: 'OpenSans',
                                          fontSize: 18,
                                        ),
                                        decoration: const InputDecoration(
                                          border: InputBorder.none,
                                          prefixIcon: Icon(
                                            Icons.mobile_friendly_outlined,
                                            color: Colors.grey,
                                          ),
                                          hintText: 'ENTER YOUR MOBILE NUMBER',
                                          hintStyle: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black54,
                                            fontFamily: 'OpenSans',
                                            fontSize: 18,
                                          ),
                                          contentPadding: EdgeInsets.symmetric(
                                              vertical: 15.0, horizontal: 20.0),
                                        ),
                                        validator: (value) =>
                                        value!.trim().isEmpty
                                            ? 'Mobile No required'
                                            : null,
                                      ),
                                    ),

                                  ],
                                ),
                              ),
                              const SizedBox(height: 20),
                              Obx(() => (_loginController.action.value == true)
                                  ? const Center(
                                child: CircularProgressIndicator(),
                              )
                                  : Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 20.0),
                                child: SizedBox(
                                  width: Get.width,
                                  child: MaterialButton(
                                      color:  AppColors.buttonColor,
                                      height: 45,
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.circular(10),
                                      ),
                                      child: const Text(
                                        'LOGIN',
                                        style: TextStyle(color: Colors.white),
                                      ),
                                      onPressed: () {
                                        if (_formKey.currentState!
                                            .validate()) {
                                          _loginController.apiLogin();

                                          // _loginController.check_app_version(version);
                                        }
                                      }),
                                ),
                              )),
                              const SizedBox(
                                height: 20,
                              ),
                              Obx(() {
                                return Text(
                                  _loginController.imageUploadStatus.value,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: Colors.red,
                                    fontSize: 23,
                                    fontWeight: FontWeight.bold,
                                  ),
                                );
                              }),
                            ]
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

              ],
            ),
          )),
    );
  }
}
