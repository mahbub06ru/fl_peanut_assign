import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:peanut/network/url.dart';

class Request {
  final String url;
  final dynamic body;
  var getdata = GetStorage();
  Request({required this.url, this.body});

  Future<http.Response> post() {
    // ignore: avoid_print
    // print(Uri.parse(urlBase + url));
    // print(body);
    return http
        .post(Uri.parse(urlBase + url), body: body)
        .timeout(const Duration(minutes: 2));
  }

  Future<http.Response> tokenPost() {
    //print('token' + getdata.read('token').toString());
    return http
        .post(
          Uri.parse(urlBase + url),
          // headers: {
          //   'Content-type': 'application/json',
          //   'Authorization': 'Bearer ${getdata.read('token')}'
          // },

          headers: {
            "Accept": "application/json",
            "Authorization": 'Bearer ${getdata.read('token')}'
          },
          body: body,
        )
        .timeout(const Duration(minutes: 2));
  }

  Future<http.Response> get() {
    return http
        .get(Uri.parse(urlBase + url))
        .timeout(const Duration(minutes: 2));
  }

  Future<http.Response> tokenGet() {
    return http.get(Uri.parse(urlBase + url), headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${getdata.read('token')}',
    }).timeout(const Duration(minutes: 2));
  }

  /////////////
  Future<http.Response> postTest() {
    return http
        .post(Uri.parse(url), body: body)
        .timeout(const Duration(minutes: 2));
  }

  Future<http.Response> upgradeApp() {
    return http.get(Uri.parse(url));
  }
}
