const urlBase = 'https://peanut.ifxdb.com/api/ClientCabinetBasic/';
const urlLogin = 'IsAccountCredentialsCorrect';
const urlGetAccount = 'GetAccountInformation';
const urlGetFourNumbers = 'GetLastFourNumbersPhone';
const urlGetOpenTraders = 'GetOpenTrades';

